//...functions for quiz mode...

//function that displays value
function display2(val) {
    if (document.getElementById("result2").value.length < 5) {
        if (val == "+" || val == "-" || val == "*" || val == "/" || val == "(" || val == ")") {
        }
        else {
            document.getElementById("result2").value += val
        }
    }
}

//function that clears the display
function ac2() {
    document.getElementById("result2").value = ""
}

//function that deletes last character
function del2() {
    var last2 = document.getElementById("result2").value;
    var last = last2.slice(0, -1);
    document.getElementById("result2").value = last;
}

//variables to use
var show = "";
var answer = "";

//function that submits the answer
function submit() {
    var x = document.getElementById("result2").value;
    if (x != "") {
        if (x == answer) {
            rewardCorrect();
        }
        else {
            rewardIncorrect();
        }
    }
    display();
}

//function that sets the text and color of show variable
function rewardCorrect() {
    show = "Правилен отговор";
    var canvas = document.getElementById("myCanvas");
    var ctx = canvas.getContext("2d");
    ctx.fillStyle = "#00FF00";
    ctx.fillRect(20, 20, 150, 100);
}

//function that sets the text and color of show variable
function rewardIncorrect() {
    show = "Неправилен отговор";
    var canvas = document.getElementById("myCanvas");
    var ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ff0000";
    ctx.fillRect(20, 20, 150, 100);
}


//function that asks question from user
function askQuestion() {
    ac2();
    //random number generation for variables and operations
    var r1 = Suica.random(1, 100);
    var r2 = Suica.random(100, 200);
    var r3 = Suica.random(1, 5);

    //numbers for variables
    var x1 = Math.floor(r2);
    var x2 = Math.floor(r1);

    //number for operation
    var x3 = Math.floor(r3);
    var operation = "";

    //question and answer generation
    if (x3 == 1) {
        operation = "+";
    } else if (x3 == 2) {
        operation = "-";
    } else if (x3 == 3) {
        operation = "*";
    } else if (x3 == 4) {
        operation = "/";
    }

    var questionbackend = x1 + operation + x2;
    answer = eval(questionbackend);
    if (operation == "/") {
        answer = Math.round(answer);
    }
    var questionDisplay = x1 + ' ' + operation + ' ' + x2 + ' = ?';

    show = questionDisplay;

    display();
}

//clear previous text on canvas
function emptyCanvas() {
    var canvas = document.getElementById("myCanvas");
    var ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// display on canvas();
function display() {
    emptyCanvas();
    var canvas = document.getElementById("myCanvas");
    var ctx = canvas.getContext("2d");
    ctx.font = "30px Arial";
    ctx.fillText(show, 10, 50);
}