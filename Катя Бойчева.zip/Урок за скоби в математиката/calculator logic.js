// functions for normal mode...

//function that display value
function display(val) {
    if (document.getElementById("result").value.length < 15) {
        if (val == "+" || val == "-" || val == "*" || val == "/") {
            var last2 = document.getElementById("result").value;
            var last = last2.slice(-1);
            if (last == "+" || last == "-" || last == "*" || last == "/") {
                var str = document.getElementById("result").value;
                var newStr = str.slice(0, -1);
                document.getElementById("result").value = newStr;
                document.getElementById("result").value += val;
            } else {
                document.getElementById("result").value += val;
            }
        }
        else {
            document.getElementById("result").value += val
        }
    }
}

//function that evaluates the digit and return result
function solve() {
    try {
        let x = document.getElementById("result").value
        let y = eval(x)
        document.getElementById("result").value = y
    }
    catch {
        document.getElementById("result").value = "undefined";
    }
}

//function that clears the display
function ac() {
    document.getElementById("result").value = ""
}

//function that deletes last character
function del() {
    var last2 = document.getElementById("result").value;
    var last = last2.slice(0, -1);
    console.log(last);
    document.getElementById("result").value = last;
}